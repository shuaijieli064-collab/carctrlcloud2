@Component
export struct Tachometer {
  //用来配置CanvasRenderingcontext对象的参数，包括是否开启抗锯齿，true表明开启抗锯齿。
  private settings: RenderingContextSettings = new RenderingContextSettings(true);
  //用来创建CanvasRenderingcontext对象，通过在canvas中调用CanvasRenderingcontext对象来绘制。
  private context: CanvasRenderingContext2D = new CanvasRenderingContext2D(this.settings);
  private speedArr = ['5', '6', '7', '8', '0', '1', '2', '3', '4'];

  private radius: number = 0; //圆环半径
  private shadowBlurRadius: number =vp2px(16); //圆环模糊阴影半径
  private speed:number = 3  //发动机实时转速

  // 画布大小
  @State mainHeight: number = 0;
  @State mainWidth: number = 0;
  build() {
    Canvas(this.context)
      .width('100%')
      .height(this.mainHeight)
      .onAreaChange((oldValue: Area, newValue: Area) => {
        this.mainHeight = Number(newValue.width)
      })
      .onReady(() => {
        this.generateRadius()  //生成表环半径
        this.drawArc();  //绘制转速表环
        this.drawNumArc(); //绘制数字环
        this.drawHand();  //绘制表盘指针
      })
  }

  //根据画布宽度和圆环阴影半径确定绘制圆环的半径
  private generateRadius() {
    this.mainWidth = this.context.width
    this.radius = this.mainWidth / 2-this.shadowBlurRadius/4;
  }

  //绘制转速表环
  private drawArc(){
    // 表环-车速
    //画布开始绘制
    this.context.beginPath()
    //确定圆心的位置
    this.context.translate(this.radius+this.shadowBlurRadius/4, this.radius+this.shadowBlurRadius/4)
    //确定阴影半径的面积
    this.context.shadowBlur = this.shadowBlurRadius
    //确定阴影部分的颜色
    this.context.shadowColor = '#FFFFFF'
    //绘制圆形
    this.context.arc(0, 0, this.radius, 0, 2 * Math.PI);
    //确定圆形的填充色
    this.context.fillStyle = '#000000'
    //进行填充绘制
    this.context.fill()
    //结束绘制
    this.context.closePath()
  }

  //绘制数字环
  private drawNumArc(){
    // 开始绘制
    this.context.beginPath()
    //设置字体，使用vp值适配屏幕，将vp转换成像素
    this.context.font = ''+fp2px(12)+'px bold'
    //设置文本居中
    this.context.textAlign = 'center'
    //设置文本基线居中
    this.context.textBaseline = "middle"
    //设置文本颜色
    this.context.fillStyle = "#ffffff"
    //根据定义的车速数组值，循环绘制数字，最终形成环形效果
    for (let i = 0;i < this.speedArr.length; i++) {
      this.context.fillText(
        this.speedArr[i],
        this.radius * 0.9 * Math.cos(((i * 40 - 70) * Math.PI) / 180),
        this.radius * 0.9 * Math.sin(((i * 40 - 70) * Math.PI) / 180)
      );
    }
    //结束绘制
    this.context.closePath()
  }

  //绘制表盘指针
  private drawHand() {
    //进行表针底部的圆行绘制--start
    this.context.beginPath()
    this.context.arc(0, 0, vp2px(2), 0,  vp2px(2))
    this.context.fillStyle = '#ff0000'
    this.context.fill()
    this.context.closePath()
    //进行表针底部的圆行绘制--end
    //根据车速计算指针指向的方向弧度
    let radius = this.speed * Math.PI / (180 / 40)
    //绘制指针，并且根据发动机实时转速调整指针的指向

    //绘制指针，并且根据发动机实时转速调整指针的指向
    this.context.beginPath()
    this.context.translate(0, 0)
    //设置指针的宽度
    this.context.lineWidth = vp2px(1)
    //设置指针的颜色
    this.context.strokeStyle = '#ff0000'
    //设置指针的指向
    this.context.rotate(radius)
    //设置指针的起点
    this.context.moveTo(0, 0)
    //设置指针的终点
    this.context.lineTo(0, this.radius * 0.6)
    this.context.stroke()
    this.context.closePath()
  }
}