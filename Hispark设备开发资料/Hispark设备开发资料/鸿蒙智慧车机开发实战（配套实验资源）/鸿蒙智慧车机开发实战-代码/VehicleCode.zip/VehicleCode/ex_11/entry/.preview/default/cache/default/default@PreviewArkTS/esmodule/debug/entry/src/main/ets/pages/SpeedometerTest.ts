if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SpeedometerTest_Params {
}
import { Speedometer } from "@bundle:com.xdw.ohcar/entry/ets/components/Speedometer";
class SpeedometerTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SpeedometerTest_Params) {
    }
    updateStateVars(params: SpeedometerTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SpeedometerTest.ets(6:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.backgroundColor(Color.Black);
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.width('100%');
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new Speedometer(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/SpeedometerTest.ets", line: 7, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "Speedometer" });
        }
        __Common__.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "SpeedometerTest";
    }
}
registerNamedRoute(() => new SpeedometerTest(undefined, {}), "", { bundleName: "com.xdw.ohcar", moduleName: "entry", pagePath: "pages/SpeedometerTest", pageFullPath: "entry/src/main/ets/pages/SpeedometerTest", integratedHsp: "false", moduleType: "followWithHap" });
