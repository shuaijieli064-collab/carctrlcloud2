if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface CanvasExample1_Params {
    settings?: RenderingContextSettings;
    context?: CanvasRenderingContext2D;
}
class CanvasExample1 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.settings = new RenderingContextSettings(true);
        this.context = new CanvasRenderingContext2D(this.settings);
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CanvasExample1_Params) {
        if (params.settings !== undefined) {
            this.settings = params.settings;
        }
        if (params.context !== undefined) {
            this.context = params.context;
        }
    }
    updateStateVars(params: CanvasExample1_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //用来配置CanvasRenderingContext2D对象的参数，包括是否开启抗锯齿，true表明开启抗锯齿。
    private settings: RenderingContextSettings;
    //用来创建CanvasRenderingContext2D对象，通过在canvas中调用CanvasRenderingContext2D对象来绘制。
    private context: CanvasRenderingContext2D;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Flex.create({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center });
            Flex.debugLine("entry/src/main/ets/pages/CanvasExample1.ets(10:5)", "entry");
            Flex.width('100%');
            Flex.height('100%');
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //在canvas中调用CanvasRenderingContext2D对象。
            Canvas.create(this.context);
            Canvas.debugLine("entry/src/main/ets/pages/CanvasExample1.ets(12:7)", "entry");
            //在canvas中调用CanvasRenderingContext2D对象。
            Canvas.width('100%');
            //在canvas中调用CanvasRenderingContext2D对象。
            Canvas.height('100%');
            //在canvas中调用CanvasRenderingContext2D对象。
            Canvas.backgroundColor('#F5DC62');
            //在canvas中调用CanvasRenderingContext2D对象。
            Canvas.onReady(() => {
                //绘制矩形
                this.context.beginPath();
                this.context.rect(100, 50, 100, 100);
                this.context.stroke();
                //绘制圆形
                this.context.beginPath();
                this.context.arc(150, 250, 50, 0, 6.28);
                this.context.stroke();
                //绘制椭圆
                this.context.beginPath();
                this.context.ellipse(150, 450, 50, 100, Math.PI * 0.25, Math.PI * 0, Math.PI * 2);
                this.context.stroke();
            });
        }, Canvas);
        //在canvas中调用CanvasRenderingContext2D对象。
        Canvas.pop();
        Flex.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "CanvasExample1";
    }
}
registerNamedRoute(() => new CanvasExample1(undefined, {}), "", { bundleName: "com.xdw.ohcar", moduleName: "entry", pagePath: "pages/CanvasExample1", pageFullPath: "entry/src/main/ets/pages/CanvasExample1", integratedHsp: "false", moduleType: "followWithHap" });
