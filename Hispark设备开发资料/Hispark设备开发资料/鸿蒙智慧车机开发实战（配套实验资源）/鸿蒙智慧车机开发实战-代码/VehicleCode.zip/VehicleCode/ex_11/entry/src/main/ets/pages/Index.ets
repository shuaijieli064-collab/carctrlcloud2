import router from '@ohos.router'
import { Speedometer } from '../components/Speedometer';
import { Tachometer } from '../components/Tachometer';

@Entry
@Component
struct Index {
  @State fuelGaugeHeight: number = 120;
  build() {
    //添加根布局
    Column() {
      //在此处添加子布局或者UI组件代码
      Column() {

      }.layoutWeight(4).backgroundColor(Color.Gray).width('100%')

      //中控菜单栏
      Row() {
        Image($r('app.media.music')).height('36vp').onClick(() => {
          //此处添加点击事件的回调操作
          router.pushUrl({
            url: "pages/Music",
          })
        })
        Image($r('app.media.aircondition')).height('36vp').onClick(() => {
          //此处添加点击事件的回调操作
          router.pushUrl({
            url: "pages/AirCondition",
          })
        })
        Image($r('app.media.navigation')).height('36vp').onClick(() => {
          //此处添加点击事件的回调操作
          router.pushUrl({
            url: "pages/Nav",
          })
        })
        Image($r('app.media.video')).height('36vp').onClick(() => {
          //此处添加点击事件的回调操作
          router.pushUrl({
            url: "pages/VideoPlay",
          })
        })
        Image($r('app.media.setting')).height('36vp').onClick(() => {
          //此处添加点击事件的回调操作
          router.pushUrl({
            url: "pages/Settings",
          })
        })
      }.layoutWeight(1).width('100%').justifyContent(FlexAlign.SpaceBetween)

      Column() {
        Row(){
          Row(){
            Tachometer().width('100%')  //转速表
          }.width('25%').height('100%').alignItems(VerticalAlign.Bottom)

          Column(){
            Speedometer().width('100%')  //时速表
            Text('速度：120KM/H').margin({top:'10vp'}).fontColor(Color.White)
          }.width('50%').height('100%').justifyContent(FlexAlign.Center)

          Row(){
            // 油量表， 210--150度环形图表
            Gauge({ value: 95, min: 0, max: 100 })
              .startAngle(210)
              .endAngle(150)
              .colors([[0xFF0000, 0.1], [0xE08C3A, 0.4], [0x5BA854, 0.5]])
              .strokeWidth('10vp')
              .width('100%')
              .height(this.fuelGaugeHeight)
              .onAreaChange((oldValue: Area, newValue: Area) => {
                console.info(`Ace: on area change, oldValue is ${JSON.stringify(oldValue)} value is ${JSON.stringify(newValue)}`)
                this.fuelGaugeHeight = Number(newValue.width) //将高度设置为同宽度一致
              })
          }.width('25%').height('100%').alignItems(VerticalAlign.Bottom)

        }.alignItems(VerticalAlign.Center)
      }.layoutWeight(6).width('95%').backgroundColor('#000000').justifyContent(FlexAlign.Center)
      .borderWidth(2).borderRadius(16)

      //车辆外设控制栏
      Row() {
        Button() {
          Image($r('app.media.engine')).height('36vp').width('36vp').onClick(() => {
            //打印日志模拟车辆控制业务
            console.info('启动车辆')
          })
        }.backgroundColor(Color.White)

        Button() {
          Image($r('app.media.danger')).height('36vp').width('36vp').onClick(() => {
            //打印日志模拟车辆控制业务
            console.info('开启双闪灯')
          })
        }.backgroundColor(Color.White)

        Button() {
          Image($r('app.media.door')).height('36vp').width('36vp').onClick(() => {
            //打印日志模拟车辆控制业务
            console.info('开启车门')
          })
        }.backgroundColor(Color.White)

        Button() {
          Image($r('app.media.wing')).height('36vp').width('36vp').onClick(() => {
            //打印日志模拟车辆控制业务
            console.info('开启汽车尾翼')
          })
        }.backgroundColor(Color.White)

        Button() {
          Image($r("app.media.head_light")).height('36vp').width('36vp').onClick(() => {
            //打印日志模拟车辆控制业务
            console.info('开启汽车大灯')
          })
        }.backgroundColor(Color.White)

      }
      .layoutWeight(1)
      .width('90%')
      .justifyContent(FlexAlign.SpaceBetween)
      .borderWidth(1)
      .borderRadius('5vp')
      .margin('10vp')
      .borderColor(Color.Gray)

      // 汽车运动控制UI
      Row() {
        // 油门踏板
        Image($r('app.media.fuel_push')).objectFit(ImageFit.Contain).width('20%').height('60%')
          .onClick(() => {
            console.info("踩油门")
          })
        // 刹车踏板-倒车踏板
        Image($r('app.media.stop')).objectFit(ImageFit.Contain).width('20%').height('60%')
          .onClick(() => {
            console.info("踩刹车")
          })
        // 左转
        Button({ type: ButtonType.Circle, stateEffect: true }) {
          Image($r('app.media.turn_left')).width(60).height(60).objectFit(ImageFit.Fill)
        }.width('20%').height('60%')
        .onClick(() => {
          console.info("左转")
        })

        // 方向前进-鸣笛
        Image($r('app.media.wheel')).objectFit(ImageFit.Contain).width('20%').height('60%')
          .onClick(() => {
            console.info("前进")
          })

        // 右转
        Button({ type: ButtonType.Circle, stateEffect: true }) {
          Image($r('app.media.turn_right')).width(60).height(60).objectFit(ImageFit.Fill)
        }.width('20%').height('60%')
        .onClick(() => {
          console.info("右转")
        })
      }
      .backgroundColor('white').justifyContent(FlexAlign.SpaceBetween)
      .alignItems(VerticalAlign.Center).layoutWeight(2)
    }
    .height('100%').width('100%')
  }
}