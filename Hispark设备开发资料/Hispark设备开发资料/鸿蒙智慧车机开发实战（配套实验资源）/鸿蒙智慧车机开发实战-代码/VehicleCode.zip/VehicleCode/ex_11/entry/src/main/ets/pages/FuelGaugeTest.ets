@Entry
@Component
struct FuelGaugeTest {
  @State fuelGaugeHeight:number = 0 //油量仪表盘高度
  build() {
    Column() {
      // 油量表， 210--150度环形图表
      Gauge({ value: 95, min: 0, max: 100 })
        .startAngle(210)
        .endAngle(150)
        .colors([[0xFF0000, 0.1], [0xE08C3A, 0.4], [0x5BA854, 0.5]])
        .strokeWidth('10vp')
        .width('100%')
        .height(this.fuelGaugeHeight)
        .onAreaChange((oldValue: Area, newValue: Area) => {
          console.info(`Ace: on area change, oldValue is ${JSON.stringify(oldValue)} value is ${JSON.stringify(newValue)}`)
          this.fuelGaugeHeight = Number(newValue.width) //将高度设置为同宽度一致
        })
    }
    .height('100%').width('100%').backgroundColor(Color.Black).justifyContent(FlexAlign.Center)
  }
}