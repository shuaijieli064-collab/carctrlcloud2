if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FuelGaugeTest_Params {
    fuelGaugeHeight?: number;
}
class FuelGaugeTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__fuelGaugeHeight = new ObservedPropertySimplePU(0 //油量仪表盘高度
        , this, "fuelGaugeHeight");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FuelGaugeTest_Params) {
        if (params.fuelGaugeHeight !== undefined) {
            this.fuelGaugeHeight = params.fuelGaugeHeight;
        }
    }
    updateStateVars(params: FuelGaugeTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__fuelGaugeHeight.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__fuelGaugeHeight.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __fuelGaugeHeight: ObservedPropertySimplePU<number>; //油量仪表盘高度
    get fuelGaugeHeight() {
        return this.__fuelGaugeHeight.get();
    }
    set fuelGaugeHeight(newValue: number) {
        this.__fuelGaugeHeight.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/FuelGaugeTest.ets(6:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.backgroundColor(Color.Black);
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 油量表， 210--150度环形图表
            Gauge.create({ value: 95, min: 0, max: 100 });
            Gauge.debugLine("entry/src/main/ets/pages/FuelGaugeTest.ets(8:7)", "entry");
            // 油量表， 210--150度环形图表
            Gauge.startAngle(210);
            // 油量表， 210--150度环形图表
            Gauge.endAngle(150);
            // 油量表， 210--150度环形图表
            Gauge.colors([[0xFF0000, 0.1], [0xE08C3A, 0.4], [0x5BA854, 0.5]]);
            // 油量表， 210--150度环形图表
            Gauge.strokeWidth('10vp');
            // 油量表， 210--150度环形图表
            Gauge.width('100%');
            // 油量表， 210--150度环形图表
            Gauge.height(this.fuelGaugeHeight);
            // 油量表， 210--150度环形图表
            Gauge.onAreaChange((oldValue: Area, newValue: Area) => {
                console.info(`Ace: on area change, oldValue is ${JSON.stringify(oldValue)} value is ${JSON.stringify(newValue)}`);
                this.fuelGaugeHeight = Number(newValue.width); //将高度设置为同宽度一致
            });
        }, Gauge);
        // 油量表， 210--150度环形图表
        Gauge.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "FuelGaugeTest";
    }
}
registerNamedRoute(() => new FuelGaugeTest(undefined, {}), "", { bundleName: "com.xdw.ohcar", moduleName: "entry", pagePath: "pages/FuelGaugeTest", pageFullPath: "entry/src/main/ets/pages/FuelGaugeTest", integratedHsp: "false", moduleType: "followWithHap" });
