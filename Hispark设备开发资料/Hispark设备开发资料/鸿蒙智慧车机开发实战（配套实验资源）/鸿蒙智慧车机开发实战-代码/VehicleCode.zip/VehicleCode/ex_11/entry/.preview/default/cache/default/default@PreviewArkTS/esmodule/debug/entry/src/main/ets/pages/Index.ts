if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    fuelGaugeHeight?: number;
}
import router from "@ohos:router";
import { Speedometer } from "@bundle:com.xdw.ohcar/entry/ets/components/Speedometer";
import { Tachometer } from "@bundle:com.xdw.ohcar/entry/ets/components/Tachometer";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__fuelGaugeHeight = new ObservedPropertySimplePU(120, this, "fuelGaugeHeight");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.fuelGaugeHeight !== undefined) {
            this.fuelGaugeHeight = params.fuelGaugeHeight;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__fuelGaugeHeight.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__fuelGaugeHeight.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __fuelGaugeHeight: ObservedPropertySimplePU<number>;
    get fuelGaugeHeight() {
        return this.__fuelGaugeHeight.get();
    }
    set fuelGaugeHeight(newValue: number) {
        this.__fuelGaugeHeight.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //添加根布局
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(11:5)", "entry");
            //添加根布局
            Column.height('100%');
            //添加根布局
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //在此处添加子布局或者UI组件代码
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(13:7)", "entry");
            //在此处添加子布局或者UI组件代码
            Column.layoutWeight(4);
            //在此处添加子布局或者UI组件代码
            Column.backgroundColor(Color.Gray);
            //在此处添加子布局或者UI组件代码
            Column.width('100%');
        }, Column);
        //在此处添加子布局或者UI组件代码
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //中控菜单栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(18:7)", "entry");
            //中控菜单栏
            Row.layoutWeight(1);
            //中控菜单栏
            Row.width('100%');
            //中控菜单栏
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777236, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(19:9)", "entry");
            Image.height('36vp');
            Image.onClick(() => {
                //此处添加点击事件的回调操作
                router.pushUrl({
                    url: "pages/Music",
                });
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777219, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(25:9)", "entry");
            Image.height('36vp');
            Image.onClick(() => {
                //此处添加点击事件的回调操作
                router.pushUrl({
                    url: "pages/AirCondition",
                });
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777227, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(31:9)", "entry");
            Image.height('36vp');
            Image.onClick(() => {
                //此处添加点击事件的回调操作
                router.pushUrl({
                    url: "pages/Nav",
                });
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777221, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(37:9)", "entry");
            Image.height('36vp');
            Image.onClick(() => {
                //此处添加点击事件的回调操作
                router.pushUrl({
                    url: "pages/VideoPlay",
                });
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777242, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(43:9)", "entry");
            Image.height('36vp');
            Image.onClick(() => {
                //此处添加点击事件的回调操作
                router.pushUrl({
                    url: "pages/Settings",
                });
            });
        }, Image);
        //中控菜单栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(51:7)", "entry");
            Column.layoutWeight(6);
            Column.width('95%');
            Column.backgroundColor('#000000');
            Column.justifyContent(FlexAlign.Center);
            Column.borderWidth(2);
            Column.borderRadius(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(52:9)", "entry");
            Row.alignItems(VerticalAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(53:11)", "entry");
            Row.width('25%');
            Row.height('100%');
            Row.alignItems(VerticalAlign.Bottom);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.width('100%');
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new Tachometer(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 54, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "Tachometer" });
        }
        __Common__.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(57:11)", "entry");
            Column.width('50%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.width('100%');
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new Speedometer(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 58, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "Speedometer" });
        }
        __Common__.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('速度：120KM/H');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(59:13)", "entry");
            Text.margin({ top: '10vp' });
            Text.fontColor(Color.White);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(62:11)", "entry");
            Row.width('25%');
            Row.height('100%');
            Row.alignItems(VerticalAlign.Bottom);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 油量表， 210--150度环形图表
            Gauge.create({ value: 95, min: 0, max: 100 });
            Gauge.debugLine("entry/src/main/ets/pages/Index.ets(64:13)", "entry");
            // 油量表， 210--150度环形图表
            Gauge.startAngle(210);
            // 油量表， 210--150度环形图表
            Gauge.endAngle(150);
            // 油量表， 210--150度环形图表
            Gauge.colors([[0xFF0000, 0.1], [0xE08C3A, 0.4], [0x5BA854, 0.5]]);
            // 油量表， 210--150度环形图表
            Gauge.strokeWidth('10vp');
            // 油量表， 210--150度环形图表
            Gauge.width('100%');
            // 油量表， 210--150度环形图表
            Gauge.height(this.fuelGaugeHeight);
            // 油量表， 210--150度环形图表
            Gauge.onAreaChange((oldValue: Area, newValue: Area) => {
                console.info(`Ace: on area change, oldValue is ${JSON.stringify(oldValue)} value is ${JSON.stringify(newValue)}`);
                this.fuelGaugeHeight = Number(newValue.width); //将高度设置为同宽度一致
            });
        }, Gauge);
        // 油量表， 210--150度环形图表
        Gauge.pop();
        Row.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //车辆外设控制栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(82:7)", "entry");
            //车辆外设控制栏
            Row.layoutWeight(1);
            //车辆外设控制栏
            Row.width('90%');
            //车辆外设控制栏
            Row.justifyContent(FlexAlign.SpaceBetween);
            //车辆外设控制栏
            Row.borderWidth(1);
            //车辆外设控制栏
            Row.borderRadius('5vp');
            //车辆外设控制栏
            Row.margin('10vp');
            //车辆外设控制栏
            Row.borderColor(Color.Gray);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(83:9)", "entry");
            Button.backgroundColor(Color.White);
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777240, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(84:11)", "entry");
            Image.height('36vp');
            Image.width('36vp');
            Image.onClick(() => {
                //打印日志模拟车辆控制业务
                console.info('启动车辆');
            });
        }, Image);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(90:9)", "entry");
            Button.backgroundColor(Color.White);
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(91:11)", "entry");
            Image.height('36vp');
            Image.width('36vp');
            Image.onClick(() => {
                //打印日志模拟车辆控制业务
                console.info('开启双闪灯');
            });
        }, Image);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(97:9)", "entry");
            Button.backgroundColor(Color.White);
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777232, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(98:11)", "entry");
            Image.height('36vp');
            Image.width('36vp');
            Image.onClick(() => {
                //打印日志模拟车辆控制业务
                console.info('开启车门');
            });
        }, Image);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(104:9)", "entry");
            Button.backgroundColor(Color.White);
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(105:11)", "entry");
            Image.height('36vp');
            Image.width('36vp');
            Image.onClick(() => {
                //打印日志模拟车辆控制业务
                console.info('开启汽车尾翼');
            });
        }, Image);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(111:9)", "entry");
            Button.backgroundColor(Color.White);
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(112:11)", "entry");
            Image.height('36vp');
            Image.width('36vp');
            Image.onClick(() => {
                //打印日志模拟车辆控制业务
                console.info('开启汽车大灯');
            });
        }, Image);
        Button.pop();
        //车辆外设控制栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 汽车运动控制UI
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(128:7)", "entry");
            // 汽车运动控制UI
            Row.backgroundColor('white');
            // 汽车运动控制UI
            Row.justifyContent(FlexAlign.SpaceBetween);
            // 汽车运动控制UI
            Row.alignItems(VerticalAlign.Center);
            // 汽车运动控制UI
            Row.layoutWeight(2);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 油门踏板
            Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(130:9)", "entry");
            // 油门踏板
            Image.objectFit(ImageFit.Contain);
            // 油门踏板
            Image.width('20%');
            // 油门踏板
            Image.height('60%');
            // 油门踏板
            Image.onClick(() => {
                console.info("踩油门");
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 刹车踏板-倒车踏板
            Image.create({ "id": 16777237, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(135:9)", "entry");
            // 刹车踏板-倒车踏板
            Image.objectFit(ImageFit.Contain);
            // 刹车踏板-倒车踏板
            Image.width('20%');
            // 刹车踏板-倒车踏板
            Image.height('60%');
            // 刹车踏板-倒车踏板
            Image.onClick(() => {
                console.info("踩刹车");
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 左转
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("entry/src/main/ets/pages/Index.ets(140:9)", "entry");
            // 左转
            Button.width('20%');
            // 左转
            Button.height('60%');
            // 左转
            Button.onClick(() => {
                console.info("左转");
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777222, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(141:11)", "entry");
            Image.width(60);
            Image.height(60);
            Image.objectFit(ImageFit.Fill);
        }, Image);
        // 左转
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 方向前进-鸣笛
            Image.create({ "id": 16777239, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(148:9)", "entry");
            // 方向前进-鸣笛
            Image.objectFit(ImageFit.Contain);
            // 方向前进-鸣笛
            Image.width('20%');
            // 方向前进-鸣笛
            Image.height('60%');
            // 方向前进-鸣笛
            Image.onClick(() => {
                console.info("前进");
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 右转
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("entry/src/main/ets/pages/Index.ets(154:9)", "entry");
            // 右转
            Button.width('20%');
            // 右转
            Button.height('60%');
            // 右转
            Button.onClick(() => {
                console.info("右转");
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777220, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(155:11)", "entry");
            Image.width(60);
            Image.height(60);
            Image.objectFit(ImageFit.Fill);
        }, Image);
        // 右转
        Button.pop();
        // 汽车运动控制UI
        Row.pop();
        //添加根布局
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.xdw.ohcar", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
