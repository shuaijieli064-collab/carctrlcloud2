import { Tachometer } from '../components/Tachometer'
@Entry
@Component
struct TachometerTest {
  build() {
    Column() {
      Tachometer().width('100%')
    }
    .height('100%').width('100%').backgroundColor(Color.Black).justifyContent(FlexAlign.Center)
  }
}