import { Speedometer } from '../components/Speedometer'
@Entry
@Component
struct SpeedometerTest {
  build() {
    Column() {
      Speedometer().width('100%')
    }
    .height('100%').width('100%').backgroundColor(Color.Black).justifyContent(FlexAlign.Center)
  }
}