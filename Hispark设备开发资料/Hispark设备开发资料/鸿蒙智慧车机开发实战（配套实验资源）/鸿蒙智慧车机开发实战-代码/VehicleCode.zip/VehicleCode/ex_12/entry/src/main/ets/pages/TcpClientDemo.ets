import socket from '@ohos.net.socket';
// 定义一个全局变量，类型为TCPSocket对象。
let tcp: socket.TCPSocket;

interface bindAddress {
  address: string;
  port: number;
  family: number;
}

interface connectAddress {
  address: string;
  port: number;
  family: number;
}

@Entry
@Component
struct TcpClientDemo {
  build() {
    Column() {
      Button('创建TcpSocket').margin('16vp').fontSize('18vp').onClick(() => {
        console.log('TcpClientDemo:创建TcpSocket')
        // 创建一个TCPSocket连接，返回一个TCPSocket对象。
        tcp = socket.constructTCPSocketInstance();
      })
      Button('订阅数据接收').margin('16vp').fontSize('18vp').onClick(() => {
        console.log('TcpClientDemo:点击订阅数据按钮')
        // 订阅TCPSocket相关的订阅事件
        tcp.on('message', value => {
          console.log("TcpClientDemo:on message")
          //buffer为接收到的数据内容
          let buffer = value.message
          //将buffer转换为字符串
          let dataView = new DataView(buffer)
          let str = ""
          for (let i = 0; i < dataView.byteLength; ++i) {
            str += String.fromCharCode(dataView.getUint8(i))
          }
          console.log("TcpClientDemo:on connect received:" + str)
        });
      })
      Button('绑定本机IP地址和端口').margin('16vp').fontSize('18vp').onClick(() => {
        console.log('TcpClientDemo:点击绑定按钮')
        // 绑定IP地址和端口。
        let bindAddress: bindAddress = {
          address: '192.168.149.117',
          port: 8080, // 绑定端口，如8888
          family: 1 //1代表IPV4，2代表IPV6,不设置默认为IPV4
        };
        tcp.bind(bindAddress, err => {
          if (err) {
            console.log('TcpClientDemo:bind fail'+JSON.stringify(err));
            return;
          }
          console.log('TcpClientDemo:bind success');
        })
      })
      Button('连接服务端IP地址和端口').margin('16vp').fontSize('18vp').onClick(() => {
        console.log('TcpClientDemo:点击连接按钮')
        // 连接到指定的IP地址和端口。
        let connectAddress: connectAddress = {
          address: '192.168.149.183',
          port: 8080, // 连接端口，如5678
          family: 1
        };
        tcp.connect({
          address: connectAddress, timeout: 10000
        }, err => {
          if (err) {
            console.log('TcpClientDemo:connect fail'+JSON.stringify(err));
            return;
          }
          console.log('TcpClientDemo:connect success');
        });
      })
      Button('发送数据').margin('16vp').fontSize('18vp').onClick(() => {
        console.log('TcpClientDemo:点击发送按钮')
        // 发送数据
        tcp.send({
          data: 'Hello, server!'
        }, err => {
          if (err) {
            console.log('send fail');
            return;
          }
          console.log('send success');
        })
      })
      Button('关闭连接').margin('16vp').fontSize('18vp').onClick(() => {
        console.log('TcpClientDemo:点击关闭按钮')
        //关闭socket连接
        tcp.close((err) => {
          console.log('TcpClientDemo:close socket.')
        });
        //关闭消息订阅
        tcp.off('message');
      })
    }
    .width('100%')
    .height('100%').justifyContent(FlexAlign.Center)
  }
}