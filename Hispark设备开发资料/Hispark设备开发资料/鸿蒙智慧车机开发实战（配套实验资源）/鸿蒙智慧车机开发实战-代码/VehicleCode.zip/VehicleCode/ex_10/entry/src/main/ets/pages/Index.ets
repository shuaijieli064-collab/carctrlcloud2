import router from '@ohos.router'

@Entry
@Component
struct Index {
  build() {
    //添加根布局
    Column() {
      //在此处添加子布局或者UI组件代码
      Column() {

      }.layoutWeight(4).backgroundColor(Color.Gray).width('100%')

      //中控菜单栏
      Row() {
        Image($r('app.media.music')).height('36vp').onClick(() => {
          //此处添加点击事件的回调操作
          router.pushUrl({
            url: "pages/Music",
          })
        })
        Image($r('app.media.aircondition')).height('36vp').onClick(() => {
          //此处添加点击事件的回调操作
          router.pushUrl({
            url: "pages/AirCondition",
          })
        })
        Image($r('app.media.navigation')).height('36vp').onClick(() => {
          //此处添加点击事件的回调操作
          router.pushUrl({
            url: "pages/Nav",
          })
        })
        Image($r('app.media.video')).height('36vp').onClick(() => {
          //此处添加点击事件的回调操作
          router.pushUrl({
            url: "pages/VideoPlay",
          })
        })
        Image($r('app.media.setting')).height('36vp').onClick(() => {
          //此处添加点击事件的回调操作
          router.pushUrl({
            url: "pages/Settings",
          })
        })
      }.layoutWeight(1).width('100%').justifyContent(FlexAlign.SpaceBetween)

      Column() {

      }.layoutWeight(4).backgroundColor('#A1D8E4').width('100%')

      //车辆外设控制栏
      Row() {
        Button() {
          Image($r('app.media.engine')).height('36vp').width('36vp').onClick(() => {
            //打印日志模拟车辆控制业务
            console.info('启动车辆')
          })
        }.backgroundColor(Color.White)

        Button() {
          Image($r('app.media.danger')).height('36vp').width('36vp').onClick(() => {
            //打印日志模拟车辆控制业务
            console.info('开启双闪灯')
          })
        }.backgroundColor(Color.White)

        Button() {
          Image($r('app.media.door')).height('36vp').width('36vp').onClick(() => {
            //打印日志模拟车辆控制业务
            console.info('开启车门')
          })
        }.backgroundColor(Color.White)

        Button() {
          Image($r('app.media.wing')).height('36vp').width('36vp').onClick(() => {
            //打印日志模拟车辆控制业务
            console.info('开启汽车尾翼')
          })
        }.backgroundColor(Color.White)

        Button() {
          Image($r("app.media.head_light")).height('36vp').width('36vp').onClick(() => {
            //打印日志模拟车辆控制业务
            console.info('开启汽车大灯')
          })
        }.backgroundColor(Color.White)

      }
      .layoutWeight(1)
      .width('90%')
      .justifyContent(FlexAlign.SpaceBetween)
      .borderWidth(1)
      .borderRadius('5vp')
      .margin('10vp')
      .borderColor(Color.Gray)

      // 汽车运动控制UI
      Row() {
        // 油门踏板
        Image($r('app.media.fuel_push')).objectFit(ImageFit.Contain).width('20%').height('60%')
          .onClick(() => {
            console.info("踩油门")
          })
        // 刹车踏板-倒车踏板
        Image($r('app.media.stop')).objectFit(ImageFit.Contain).width('20%').height('60%')
          .onClick(() => {
            console.info("踩刹车")
          })
        // 左转
        Button({ type: ButtonType.Circle, stateEffect: true }) {
          Image($r('app.media.turn_left')).width(60).height(60).objectFit(ImageFit.Fill)
        }.width('20%').height('60%')
        .onClick(() => {
          console.info("左转")
        })

        // 方向前进-鸣笛
        Image($r('app.media.wheel')).objectFit(ImageFit.Contain).width('20%').height('60%')
          .onClick(() => {
            console.info("前进")
          })

        // 右转
        Button({ type: ButtonType.Circle, stateEffect: true }) {
          Image($r('app.media.turn_right')).width(60).height(60).objectFit(ImageFit.Fill)
        }.width('20%').height('60%')
        .onClick(() => {
          console.info("右转")
        })
      }
      .backgroundColor('white').justifyContent(FlexAlign.SpaceBetween)
      .alignItems(VerticalAlign.Center).layoutWeight(2)
    }
    .height('100%').width('100%')
  }
}