if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
}
import router from "@ohos:router";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //添加根布局
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(8:5)", "entry");
            //添加根布局
            Column.height('100%');
            //添加根布局
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //在此处添加子布局或者UI组件代码
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(10:7)", "entry");
            //在此处添加子布局或者UI组件代码
            Column.layoutWeight(4);
            //在此处添加子布局或者UI组件代码
            Column.backgroundColor(Color.Gray);
            //在此处添加子布局或者UI组件代码
            Column.width('100%');
        }, Column);
        //在此处添加子布局或者UI组件代码
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //中控菜单栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(15:7)", "entry");
            //中控菜单栏
            Row.layoutWeight(1);
            //中控菜单栏
            Row.width('100%');
            //中控菜单栏
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777236, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(16:9)", "entry");
            Image.height('36vp');
            Image.onClick(() => {
                //此处添加点击事件的回调操作
                router.pushUrl({
                    url: "pages/Music",
                });
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777225, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(22:9)", "entry");
            Image.height('36vp');
            Image.onClick(() => {
                //此处添加点击事件的回调操作
                router.pushUrl({
                    url: "pages/AirCondition",
                });
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777241, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(28:9)", "entry");
            Image.height('36vp');
            Image.onClick(() => {
                //此处添加点击事件的回调操作
                router.pushUrl({
                    url: "pages/Nav",
                });
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777233, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(34:9)", "entry");
            Image.height('36vp');
            Image.onClick(() => {
                //此处添加点击事件的回调操作
                router.pushUrl({
                    url: "pages/VideoPlay",
                });
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777220, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(40:9)", "entry");
            Image.height('36vp');
            Image.onClick(() => {
                //此处添加点击事件的回调操作
                router.pushUrl({
                    url: "pages/Settings",
                });
            });
        }, Image);
        //中控菜单栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(48:7)", "entry");
            Column.layoutWeight(4);
            Column.backgroundColor('#A1D8E4');
            Column.width('100%');
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //车辆外设控制栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(53:7)", "entry");
            //车辆外设控制栏
            Row.layoutWeight(1);
            //车辆外设控制栏
            Row.width('90%');
            //车辆外设控制栏
            Row.justifyContent(FlexAlign.SpaceBetween);
            //车辆外设控制栏
            Row.borderWidth(1);
            //车辆外设控制栏
            Row.borderRadius('5vp');
            //车辆外设控制栏
            Row.margin('10vp');
            //车辆外设控制栏
            Row.borderColor(Color.Gray);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(54:9)", "entry");
            Button.backgroundColor(Color.White);
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777226, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(55:11)", "entry");
            Image.height('36vp');
            Image.width('36vp');
            Image.onClick(() => {
                //打印日志模拟车辆控制业务
                console.info('启动车辆');
            });
        }, Image);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(61:9)", "entry");
            Button.backgroundColor(Color.White);
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777239, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(62:11)", "entry");
            Image.height('36vp');
            Image.width('36vp');
            Image.onClick(() => {
                //打印日志模拟车辆控制业务
                console.info('开启双闪灯');
            });
        }, Image);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(68:9)", "entry");
            Button.backgroundColor(Color.White);
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777232, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(69:11)", "entry");
            Image.height('36vp');
            Image.width('36vp');
            Image.onClick(() => {
                //打印日志模拟车辆控制业务
                console.info('开启车门');
            });
        }, Image);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(75:9)", "entry");
            Button.backgroundColor(Color.White);
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(76:11)", "entry");
            Image.height('36vp');
            Image.width('36vp');
            Image.onClick(() => {
                //打印日志模拟车辆控制业务
                console.info('开启汽车尾翼');
            });
        }, Image);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(82:9)", "entry");
            Button.backgroundColor(Color.White);
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(83:11)", "entry");
            Image.height('36vp');
            Image.width('36vp');
            Image.onClick(() => {
                //打印日志模拟车辆控制业务
                console.info('开启汽车大灯');
            });
        }, Image);
        Button.pop();
        //车辆外设控制栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 汽车运动控制UI
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(99:7)", "entry");
            // 汽车运动控制UI
            Row.backgroundColor('white');
            // 汽车运动控制UI
            Row.justifyContent(FlexAlign.SpaceBetween);
            // 汽车运动控制UI
            Row.alignItems(VerticalAlign.Center);
            // 汽车运动控制UI
            Row.layoutWeight(2);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 油门踏板
            Image.create({ "id": 16777219, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(101:9)", "entry");
            // 油门踏板
            Image.objectFit(ImageFit.Contain);
            // 油门踏板
            Image.width('20%');
            // 油门踏板
            Image.height('60%');
            // 油门踏板
            Image.onClick(() => {
                console.info("踩油门");
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 刹车踏板-倒车踏板
            Image.create({ "id": 16777242, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(106:9)", "entry");
            // 刹车踏板-倒车踏板
            Image.objectFit(ImageFit.Contain);
            // 刹车踏板-倒车踏板
            Image.width('20%');
            // 刹车踏板-倒车踏板
            Image.height('60%');
            // 刹车踏板-倒车踏板
            Image.onClick(() => {
                console.info("踩刹车");
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 左转
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("entry/src/main/ets/pages/Index.ets(111:9)", "entry");
            // 左转
            Button.width('20%');
            // 左转
            Button.height('60%');
            // 左转
            Button.onClick(() => {
                console.info("左转");
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777237, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(112:11)", "entry");
            Image.width(60);
            Image.height(60);
            Image.objectFit(ImageFit.Fill);
        }, Image);
        // 左转
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 方向前进-鸣笛
            Image.create({ "id": 16777228, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(119:9)", "entry");
            // 方向前进-鸣笛
            Image.objectFit(ImageFit.Contain);
            // 方向前进-鸣笛
            Image.width('20%');
            // 方向前进-鸣笛
            Image.height('60%');
            // 方向前进-鸣笛
            Image.onClick(() => {
                console.info("前进");
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 右转
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("entry/src/main/ets/pages/Index.ets(125:9)", "entry");
            // 右转
            Button.width('20%');
            // 右转
            Button.height('60%');
            // 右转
            Button.onClick(() => {
                console.info("右转");
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777218, "type": 20000, params: [], "bundleName": "com.xdw.ohcar", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(126:11)", "entry");
            Image.width(60);
            Image.height(60);
            Image.objectFit(ImageFit.Fill);
        }, Image);
        // 右转
        Button.pop();
        // 汽车运动控制UI
        Row.pop();
        //添加根布局
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.xdw.ohcar", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
